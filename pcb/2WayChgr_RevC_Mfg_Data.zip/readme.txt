BOARD SPEC:
Board ID:              2WayChgr_RevC
Date:                  15-Apr-2014

RoHS:                  This PCB is RoHS and Lead-free
Material:              FR4
Layers:                2
Material Details:      Standard Tg 140�C
Board Size (Width):    68.00mm
Board Size (Height:    94.00mm
Thickness:             1.6mm
Finish:                Lead Free HASL
Copper Weight:         1oz (35um) 
Min Trace/Space:       0.20mm
Min Annular Ring:      0.30mm
Smallest Holes:        0.90mm
Unplated Holes:        8
Plated Holes:          143
Surface Mount:         1 side
Solder Mask:           Both sides
Peelable Solder Mask:  None
Solder Mask Colour:    Green
Matte Colour:          None
Silkscreen:            1 side
Silkscreen Colour:     WHITE
Gold Fingers:          No
Gold Fingers Number:   0
Gold Fingers Chamfer:  None
Slots in Board:        No Slot in Board
Slots qty in Board:    0

CAD DESIGN BY:
Neil Allison
Avn Technical Solutions Ltd
13 Richards Ave
PO Box 20350
Christchurch 8053
NEW ZEALAND
Mobile: +64 21 765 884
Tel:    +64 3 354 8587
email:  neil@avon-tech-solutions.co.nz 
Skype:  neil_allison
QQ:     910125176
Cad software:  Cadsoft EAGLE 5.12.0 Windows
For any questions or comments please contact Neil Allison

FILES INCLUDED:
     NAME								FORMAT			CONTENTS
 1.  readme.txt							Text			This file
 2.  2WayChgr_RevC_board_outline.gm1			Gerber RS274X	Mechanical Layer (board outline & npth drills)
 3.  2WayChgr_RevC_bottom_copper.gbl				Gerber RS274X	Bottom (Solder side) Copper
 4.  2WayChgr_RevC_bottom_soldermask.gbs				Gerber RS274X	Bottom (Solder side) Soldermask
 5.  2WayChgr_RevC_drills.txt			Excellon		Drill File - All Drills combined. ALL HOLES ARE FINISHED SIZE
 6.  2WayChgr_RevC_drills_NPTH.txt			Excellon		Drill File - Non-plated Through Holes.  ALL HOLES ARE FINISHED SIZE
 7.  2WayChgr_RevC_top_copper.gtl				Gerber RS274X	Top Copper 
 8.  2WayChgr_RevC_top_silk.gto				Gerber RS274X	Top Silkscreen
 9.  2WayChgr_RevC_top_soldermask.gts				Gerber RS274X	Top Solder Mask 
